<?php
$file = $_GET['title'];
$file .= '.html';
$file1= 'new.html';
include ($file) ;
?>